import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import AuthStateRouter from "components/ui/AuthStateRouter";

// Import pages
import SignInScreen from "pages/sign-in-screen";
import SignUpScreen from "pages/sign-up-screen";
import ModalOverlayComponent from "pages/modal-overlay-component";
import PasswordResetScreen from "pages/password-reset-screen";
import AuthenticationSuccessScreen from "pages/authentication-success-screen";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <AuthStateRouter>
          <ScrollToTop />
          <RouterRoutes>
            <Route path="/" element={<SignInScreen />} />
            <Route path="/sign-in-screen" element={<SignInScreen />} />
            <Route path="/sign-up-screen" element={<SignUpScreen />} />
            <Route path="/modal-overlay-component" element={<ModalOverlayComponent />} />
            <Route path="/password-reset-screen" element={<PasswordResetScreen />} />
            <Route path="/authentication-success-screen" element={<AuthenticationSuccessScreen />} />
          </RouterRoutes>
        </AuthStateRouter>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;