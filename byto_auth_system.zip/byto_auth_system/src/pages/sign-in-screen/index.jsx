import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuthState } from 'components/ui/AuthStateRouter';
import AuthFormContainer from 'components/ui/AuthFormContainer';
import Icon from 'components/AppIcon';
import SignInForm from './components/SignInForm';
import SocialAuthButtons from './components/SocialAuthButtons';
import AuthLogo from './components/AuthLogo';

function SignInScreen() {
  const location = useLocation();
  const { loading, error, clearError } = useAuthState();
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (location.state?.message) {
      setSuccessMessage(location.state.message);
      // Clear the message after 5 seconds
      const timer = setTimeout(() => {
        setSuccessMessage('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [location.state]);

  useEffect(() => {
    // Clear any existing errors when component mounts
    clearError();
  }, [clearError]);

  return (
    <AuthFormContainer>
      <div className="space-y-6">
        {/* Logo Section */}
        <AuthLogo />

        {/* Success Message */}
        {successMessage && (
          <div className="bg-success-100 border border-success-500 text-success-600 px-4 py-3 rounded-md text-sm animate-fade-in">
            <div className="flex items-center gap-2">
              <Icon name="CheckCircle" size={16} />
              {successMessage}
            </div>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="bg-error-100 border border-error-500 text-error-600 px-4 py-3 rounded-md text-sm animate-fade-in">
            <div className="flex items-center gap-2">
              <Icon name="AlertCircle" size={16} />
              {error}
            </div>
          </div>
        )}

        {/* Social Authentication */}
        <SocialAuthButtons />

        {/* Divider */}
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-surface text-text-muted">or continue with email</span>
          </div>
        </div>

        {/* Sign In Form */}
        <SignInForm loading={loading} />
      </div>
    </AuthFormContainer>
  );
}

export default SignInScreen;