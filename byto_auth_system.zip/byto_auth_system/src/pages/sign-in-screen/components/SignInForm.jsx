import React, { useState } from 'react';
import { useAuthState } from 'components/ui/AuthStateRouter';
import Icon from 'components/AppIcon';

function SignInForm({ loading }) {
  const { signIn, navigateToSignUp, navigateToPasswordReset } = useAuthState();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});

  const validateForm = () => {
    const errors = {};
    
    if (!formData.email) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }
    
    if (!formData.password) {
      errors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear validation error when user starts typing
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    await signIn(formData);
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Email Field */}
      <div>
        <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">
          Email Address
        </label>
        <div className="relative">
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            className={`auth-input pl-10 ${validationErrors.email ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
            placeholder="Enter your email"
            disabled={loading}
            autoComplete="email"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="Mail" size={16} className="text-text-muted" />
          </div>
        </div>
        {validationErrors.email && (
          <p className="mt-1 text-sm text-error-500 flex items-center gap-1">
            <Icon name="AlertCircle" size={14} />
            {validationErrors.email}
          </p>
        )}
      </div>

      {/* Password Field */}
      <div>
        <label htmlFor="password" className="block text-sm font-medium text-text-primary mb-2">
          Password
        </label>
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            id="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            className={`auth-input pl-10 pr-10 ${validationErrors.password ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
            placeholder="Enter your password"
            disabled={loading}
            autoComplete="current-password"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="Lock" size={16} className="text-text-muted" />
          </div>
          <button
            type="button"
            onClick={togglePasswordVisibility}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-text-muted hover:text-text-primary transition-colors duration-200"
            disabled={loading}
          >
            <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={16} />
          </button>
        </div>
        {validationErrors.password && (
          <p className="mt-1 text-sm text-error-500 flex items-center gap-1">
            <Icon name="AlertCircle" size={14} />
            {validationErrors.password}
          </p>
        )}
      </div>

      {/* Forgot Password Link */}
      <div className="text-right">
        <button
          type="button"
          onClick={navigateToPasswordReset}
          className="text-sm auth-link"
          disabled={loading}
        >
          Forgot your password?
        </button>
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        disabled={loading}
        className="auth-button flex items-center justify-center gap-2"
      >
        {loading ? (
          <>
            <Icon name="Loader2" size={16} className="animate-spin" />
            Signing In...
          </>
        ) : (
          <>
            <Icon name="LogIn" size={16} />
            Sign In
          </>
        )}
      </button>

      {/* Sign Up Link */}
      <div className="text-center pt-4 border-t border-border">
        <p className="text-sm text-text-secondary">
          Don't have an account?{' '}
          <button
            type="button"
            onClick={navigateToSignUp}
            className="auth-link"
            disabled={loading}
          >
            Create Account
          </button>
        </p>
      </div>

      {/* Mock Credentials Info */}
      <div className="mt-6 p-4 bg-secondary-100 rounded-md">
        <p className="text-xs text-text-secondary mb-2 font-medium">Demo Credentials:</p>
        <p className="text-xs text-text-muted">Email: demo@byto.com</p>
        <p className="text-xs text-text-muted">Password: demo123</p>
      </div>
    </form>
  );
}

export default SignInForm;