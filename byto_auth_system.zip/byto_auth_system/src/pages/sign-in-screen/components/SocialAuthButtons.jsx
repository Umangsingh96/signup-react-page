import React from 'react';
import Icon from 'components/AppIcon';

function SocialAuthButtons() {
  const socialProviders = [
    {
      name: 'Google',
      icon: 'Chrome',
      color: 'text-red-500',
      bgColor: 'hover:bg-red-50'
    },
    {
      name: 'GitHub',
      icon: 'Github',
      color: 'text-gray-700',
      bgColor: 'hover:bg-gray-50'
    },
    {
      name: 'Microsoft',
      icon: 'Square',
      color: 'text-blue-600',
      bgColor: 'hover:bg-blue-50'
    }
  ];

  const handleSocialAuth = (provider) => {
    // Mock social authentication
    console.log(`Authenticating with ${provider}`);
  };

  return (
    <div className="space-y-3">
      <p className="text-sm text-text-secondary text-center">Sign in with</p>
      <div className="grid grid-cols-3 gap-3">
        {socialProviders.map((provider) => (
          <button
            key={provider.name}
            onClick={() => handleSocialAuth(provider.name)}
            className={`flex items-center justify-center p-3 border border-border rounded-md transition-all duration-200 ${provider.bgColor} hover:border-primary/30 focus:outline-none focus:ring-2 focus:ring-primary/20`}
            title={`Sign in with ${provider.name}`}
          >
            <Icon 
              name={provider.icon} 
              size={20} 
              className={provider.color}
            />
          </button>
        ))}
      </div>
    </div>
  );
}

export default SocialAuthButtons;