import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import { useAuthState } from 'components/ui/AuthStateRouter';

function ModalOverlayComponent() {
  const navigate = useNavigate();
  const { signIn, signUp, resetPassword, loading, error, clearError } = useAuthState();
  const [isOpen, setIsOpen] = useState(false);
  const [modalType, setModalType] = useState('signin');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    confirmPassword: ''
  });
  const modalRef = useRef(null);
  const previousFocusRef = useRef(null);

  // Mock data for demonstration
  const modalConfigs = {
    signin: {
      title: 'Sign In',
      description: 'Welcome back! Please sign in to your account.',
      primaryAction: 'Sign In',
      secondaryAction: 'Create Account',
      fields: ['email', 'password']
    },
    signup: {
      title: 'Create Account',
      description: 'Join us today! Create your account to get started.',
      primaryAction: 'Create Account',
      secondaryAction: 'Sign In',
      fields: ['name', 'email', 'password', 'confirmPassword']
    },
    reset: {
      title: 'Reset Password',
      description: 'Enter your email address and we\'ll send you instructions to reset your password.',
      primaryAction: 'Send Instructions',
      secondaryAction: 'Back to Sign In',
      fields: ['email']
    },
    confirmation: {
      title: 'Confirm Action',
      description: 'Are you sure you want to proceed with this action?',
      primaryAction: 'Confirm',
      secondaryAction: 'Cancel',
      fields: []
    }
  };

  const demoActions = [
    { id: 'signin', label: 'Sign In Modal', icon: 'LogIn' },
    { id: 'signup', label: 'Sign Up Modal', icon: 'UserPlus' },
    { id: 'reset', label: 'Password Reset Modal', icon: 'Key' },
    { id: 'confirmation', label: 'Confirmation Modal', icon: 'AlertCircle' }
  ];

  useEffect(() => {
    if (isOpen) {
      previousFocusRef.current = document.activeElement;
      modalRef.current?.focus();
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
      previousFocusRef.current?.focus();
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isOpen) {
        closeModal();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen]);

  const openModal = (type) => {
    setModalType(type);
    setIsOpen(true);
    clearError();
    setFormData({
      email: '',
      password: '',
      name: '',
      confirmPassword: ''
    });
  };

  const closeModal = () => {
    setIsOpen(false);
    clearError();
  };

  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) {
      closeModal();
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Tab') {
      const focusableElements = modalRef.current?.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabIndex="-1"])'
      );
      
      if (focusableElements?.length) {
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (e.shiftKey && document.activeElement === firstElement) {
          e.preventDefault();
          lastElement.focus();
        } else if (!e.shiftKey && document.activeElement === lastElement) {
          e.preventDefault();
          firstElement.focus();
        }
      }
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePrimaryAction = async () => {
    if (modalType === 'signin') {
      await signIn(formData);
    } else if (modalType === 'signup') {
      if (formData.password !== formData.confirmPassword) {
        return;
      }
      await signUp(formData);
    } else if (modalType === 'reset') {
      await resetPassword(formData.email);
    } else if (modalType === 'confirmation') {
      closeModal();
    }
  };

  const handleSecondaryAction = () => {
    if (modalType === 'signin') {
      setModalType('signup');
    } else if (modalType === 'signup') {
      setModalType('signin');
    } else if (modalType === 'reset') {
      setModalType('signin');
    } else {
      closeModal();
    }
  };

  const navigateToPage = (route) => {
    navigate(route);
  };

  const renderField = (fieldName) => {
    const fieldConfig = {
      name: { type: 'text', placeholder: 'Full Name', label: 'Full Name' },
      email: { type: 'email', placeholder: 'Email Address', label: 'Email' },
      password: { type: 'password', placeholder: 'Password', label: 'Password' },
      confirmPassword: { type: 'password', placeholder: 'Confirm Password', label: 'Confirm Password' }
    };

    const config = fieldConfig[fieldName];
    if (!config) return null;

    return (
      <div key={fieldName} className="mb-4">
        <label htmlFor={fieldName} className="block text-sm font-medium text-text-primary mb-2">
          {config.label}
        </label>
        <input
          id={fieldName}
          name={fieldName}
          type={config.type}
          value={formData[fieldName]}
          onChange={handleInputChange}
          placeholder={config.placeholder}
          className="auth-input"
          required
        />
      </div>
    );
  };

  const currentConfig = modalConfigs[modalType];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-surface border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Icon name="Layers" size={24} className="text-primary" />
              <h1 className="text-xl font-semibold text-text-primary">BYTO Auth System</h1>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <button
                onClick={() => navigateToPage('/sign-in-screen')}
                className="text-text-secondary hover:text-primary transition-colors duration-200"
              >
                Sign In Page
              </button>
              <button
                onClick={() => navigateToPage('/sign-up-screen')}
                className="text-text-secondary hover:text-primary transition-colors duration-200"
              >
                Sign Up Page
              </button>
              <button
                onClick={() => navigateToPage('/password-reset-screen')}
                className="text-text-secondary hover:text-primary transition-colors duration-200"
              >
                Password Reset
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-text-primary mb-4">Modal Overlay Component</h2>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto">
            Flexible container functionality for authentication flows and secondary actions. 
            Experience responsive modal behavior across different screen sizes with proper 
            accessibility features and smooth animations.
          </p>
        </div>

        {/* Demo Actions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {demoActions.map((action) => (
            <button
              key={action.id}
              onClick={() => openModal(action.id)}
              className="bg-surface border border-border rounded-lg p-6 hover:border-primary hover:shadow-md transition-all duration-200 group"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary-200 transition-colors duration-200">
                  <Icon name={action.icon} size={24} className="text-primary" />
                </div>
                <h3 className="font-semibold text-text-primary mb-2">{action.label}</h3>
                <p className="text-sm text-text-secondary">
                  Click to open {action.label.toLowerCase()}
                </p>
              </div>
            </button>
          ))}
        </div>

        {/* Features Section */}
        <div className="bg-surface rounded-xl border border-border p-8">
          <h3 className="text-2xl font-bold text-text-primary mb-6">Modal Features</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="flex items-start gap-3">
              <Icon name="Smartphone" size={20} className="text-primary mt-1" />
              <div>
                <h4 className="font-semibold text-text-primary mb-1">Mobile-First Design</h4>
                <p className="text-sm text-text-secondary">
                  Full viewport on mobile with slide-up animation
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Icon name="Monitor" size={20} className="text-primary mt-1" />
              <div>
                <h4 className="font-semibold text-text-primary mb-1">Desktop Centered</h4>
                <p className="text-sm text-text-secondary">
                  Centered cards with maximum width constraints
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Icon name="Accessibility" size={20} className="text-primary mt-1" />
              <div>
                <h4 className="font-semibold text-text-primary mb-1">Accessibility</h4>
                <p className="text-sm text-text-secondary">
                  Keyboard navigation and focus management
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Icon name="Zap" size={20} className="text-primary mt-1" />
              <div>
                <h4 className="font-semibold text-text-primary mb-1">Smooth Animations</h4>
                <p className="text-sm text-text-secondary">
                  Entrance/exit transitions with loading states
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Icon name="Shield" size={20} className="text-primary mt-1" />
              <div>
                <h4 className="font-semibold text-text-primary mb-1">Backdrop Protection</h4>
                <p className="text-sm text-text-secondary">
                  Semi-transparent overlay prevents interaction
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Icon name="Navigation" size={20} className="text-primary mt-1" />
              <div>
                <h4 className="font-semibold text-text-primary mb-1">Router Integration</h4>
                <p className="text-sm text-text-secondary">
                  Seamless URL management and browser history
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Modal Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
          onClick={handleOverlayClick}
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
        >
          <div 
            ref={modalRef}
            className="bg-surface rounded-xl shadow-lg w-full max-w-md max-h-[90vh] overflow-y-auto animate-scale-in"
            tabIndex={-1}
            onKeyDown={handleKeyDown}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h2 id="modal-title" className="text-xl font-semibold text-text-primary">
                {currentConfig.title}
              </h2>
              <button
                onClick={closeModal}
                className="p-2 text-text-secondary hover:text-text-primary hover:bg-secondary-100 rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary/20"
                aria-label="Close modal"
              >
                <Icon name="X" size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <p className="text-text-secondary mb-6">{currentConfig.description}</p>

              {error && (
                <div className="bg-error-100 border border-error-500 text-error-600 px-4 py-3 rounded-md mb-4">
                  <div className="flex items-center gap-2">
                    <Icon name="AlertCircle" size={16} />
                    <span className="text-sm">{error}</span>
                  </div>
                </div>
              )}

              {/* Form Fields */}
              {currentConfig.fields.length > 0 && (
                <form onSubmit={(e) => e.preventDefault()}>
                  {currentConfig.fields.map(renderField)}
                  
                  {modalType === 'signup' && formData.password !== formData.confirmPassword && formData.confirmPassword && (
                    <p className="text-error-500 text-sm mt-1">Passwords do not match</p>
                  )}
                </form>
              )}

              {/* Modal Actions */}
              <div className="flex flex-col sm:flex-row gap-3 mt-6">
                <button
                  onClick={handlePrimaryAction}
                  disabled={loading}
                  className="auth-button flex items-center justify-center gap-2"
                >
                  {loading && <Icon name="Loader2" size={16} className="animate-spin" />}
                  {currentConfig.primaryAction}
                </button>
                <button
                  onClick={handleSecondaryAction}
                  className="w-full bg-transparent text-primary border border-primary py-2.5 px-4 rounded-md font-medium hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:ring-offset-2 transition-all duration-200"
                >
                  {currentConfig.secondaryAction}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-surface border-t border-border mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-text-secondary">
              © {new Date().getFullYear()} BYTO Auth System. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default ModalOverlayComponent;