import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthState } from 'components/ui/AuthStateRouter';
import Icon from 'components/AppIcon';

function AuthenticationSuccessScreen() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthState();
  const [countdown, setCountdown] = useState(5);
  const [isRedirecting, setIsRedirecting] = useState(false);

  // Mock user data for demonstration
  const mockUser = user || {
    name: "John Doe",
    email: "john.doe@example.com",
    isNewUser: true
  };

  useEffect(() => {
    if (!isAuthenticated && !user) {
      navigate('/sign-in-screen');
      return;
    }

    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          setIsRedirecting(true);
          clearInterval(timer);
          // Simulate redirect to dashboard
          setTimeout(() => {
            navigate('/sign-in-screen'); // Redirect to sign-in as we don't have a dashboard
          }, 1000);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isAuthenticated, user, navigate]);

  const handleContinue = () => {
    setIsRedirecting(true);
    setTimeout(() => {
      navigate('/sign-in-screen'); // Redirect to sign-in as we don't have a dashboard
    }, 500);
  };

  const handleBackToAuth = () => {
    navigate('/sign-in-screen');
  };

  const features = [
    {
      icon: "Shield",
      title: "Secure Account",
      description: "Your account is protected with industry-standard security measures"
    },
    {
      icon: "Users",
      title: "Community Access",
      description: "Connect with thousands of users in our growing community"
    },
    {
      icon: "Settings",
      title: "Personalization",
      description: "Customize your experience with personalized settings and preferences"
    },
    {
      icon: "Zap",
      title: "Advanced Features",
      description: "Access premium tools and features to enhance your productivity"
    }
  ];

  if (isRedirecting) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center max-w-md mx-auto">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-primary border-t-transparent mx-auto mb-6"></div>
          <h2 className="text-xl font-semibold text-text-primary mb-2">Redirecting...</h2>
          <p className="text-text-secondary">Taking you to your dashboard</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-surface border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="Check" size={20} color="white" />
              </div>
              <h1 className="text-xl font-semibold text-text-primary">BYTO Auth</h1>
            </div>
            <button
              onClick={handleBackToAuth}
              className="text-text-secondary hover:text-text-primary transition-colors duration-200"
            >
              <Icon name="ArrowLeft" size={20} />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 md:py-16">
        <div className="text-center mb-12">
          {/* Success Animation */}
          <div className="relative mb-8">
            <div className="w-24 h-24 md:w-32 md:h-32 bg-success-100 rounded-full flex items-center justify-center mx-auto mb-6 animate-scale-in">
              <Icon name="CheckCircle" size={48} className="text-success-500 md:w-16 md:h-16" />
            </div>
            <div className="absolute inset-0 w-24 h-24 md:w-32 md:h-32 bg-success-500/20 rounded-full mx-auto animate-ping"></div>
          </div>

          {/* Welcome Message */}
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-text-primary mb-4">
              {mockUser.isNewUser ? 'Welcome to BYTO!' : 'Welcome Back!'}
            </h1>
            <p className="text-lg md:text-xl text-text-secondary mb-2">
              Hello, {mockUser.name}
            </p>
            <p className="text-text-muted">
              {mockUser.isNewUser 
                ? 'Your account has been successfully created and verified.'
                : 'You have successfully signed in to your account.'
              }
            </p>
          </div>

          {/* Auto Redirect Notice */}
          <div className="bg-primary-50 border border-primary-100 rounded-lg p-4 mb-8 max-w-md mx-auto">
            <div className="flex items-center gap-3 text-primary-700">
              <Icon name="Clock" size={20} />
              <span className="text-sm font-medium">
                Redirecting to dashboard in {countdown} seconds
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <button
              onClick={handleContinue}
              className="auth-button bg-primary hover:bg-primary-700 text-white px-8 py-3 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Icon name="ArrowRight" size={20} />
              {mockUser.isNewUser ? 'Get Started' : 'Continue to Dashboard'}
            </button>
            <button
              onClick={handleBackToAuth}
              className="px-8 py-3 border border-border rounded-lg font-medium text-text-secondary hover:text-text-primary hover:bg-secondary-50 transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Icon name="ArrowLeft" size={20} />
              Back to Authentication
            </button>
          </div>
        </div>

        {/* Feature Highlights for New Users */}
        {mockUser.isNewUser && (
          <div className="bg-surface rounded-xl border border-border p-6 md:p-8">
            <h2 className="text-2xl font-bold text-text-primary mb-6 text-center">
              What's Next?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div key={index} className="flex gap-4 p-4 rounded-lg hover:bg-secondary-50 transition-colors duration-200">
                  <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name={feature.icon} size={24} className="text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-text-primary mb-2">{feature.title}</h3>
                    <p className="text-sm text-text-secondary">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Account Summary for Returning Users */}
        {!mockUser.isNewUser && (
          <div className="bg-surface rounded-xl border border-border p-6 md:p-8">
            <h2 className="text-2xl font-bold text-text-primary mb-6 text-center">
              Account Summary
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 rounded-lg bg-secondary-50">
                <Icon name="Calendar" size={32} className="text-primary-600 mx-auto mb-3" />
                <h3 className="font-semibold text-text-primary mb-1">Last Login</h3>
                <p className="text-sm text-text-secondary">2 days ago</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-secondary-50">
                <Icon name="Activity" size={32} className="text-success-600 mx-auto mb-3" />
                <h3 className="font-semibold text-text-primary mb-1">Account Status</h3>
                <p className="text-sm text-success-600 font-medium">Active</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-secondary-50">
                <Icon name="Mail" size={32} className="text-accent-600 mx-auto mb-3" />
                <h3 className="font-semibold text-text-primary mb-1">Email</h3>
                <p className="text-sm text-text-secondary">Verified</p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-surface border-t border-border mt-16">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-text-secondary">
              <Icon name="Shield" size={16} />
              <span className="text-sm">Secured by BYTO Auth System</span>
            </div>
            <div className="text-sm text-text-muted">
              © {new Date().getFullYear()} BYTO. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default AuthenticationSuccessScreen;