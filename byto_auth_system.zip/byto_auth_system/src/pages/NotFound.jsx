import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';

function NotFound() {
  const navigate = useNavigate();

  const handleGoHome = () => {
    navigate('/sign-in-screen');
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center max-w-md mx-auto">
        <div className="mb-8">
          <Icon name="AlertTriangle" size={64} className="text-warning-500 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-text-primary mb-2">404</h1>
          <h2 className="text-xl font-semibold text-text-secondary mb-4">Page Not Found</h2>
          <p className="text-text-muted mb-8">
            The page you're looking for doesn't exist or has been moved.
          </p>
        </div>
        
        <button
          onClick={handleGoHome}
          className="auth-button inline-flex items-center gap-2"
        >
          <Icon name="Home" size={20} />
          Go to Sign In
        </button>
      </div>
    </div>
  );
}

export default NotFound;