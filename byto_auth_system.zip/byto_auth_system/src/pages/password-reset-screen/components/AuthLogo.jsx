import React from 'react';
import Icon from 'components/AppIcon';

function AuthLogo() {
  return (
    <div className="text-center mb-8">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-xl mb-4">
        <Icon name="KeyRound" size={32} color="white" />
      </div>
      <h1 className="text-2xl font-bold text-text-primary mb-2">Reset Password</h1>
      <p className="text-text-secondary">Enter your email to receive reset instructions</p>
    </div>
  );
}

export default AuthLogo;