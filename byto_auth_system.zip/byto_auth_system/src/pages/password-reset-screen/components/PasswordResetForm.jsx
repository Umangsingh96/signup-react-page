import React, { useState } from 'react';
import { useAuthState } from 'components/ui/AuthStateRouter';
import Icon from 'components/AppIcon';

function PasswordResetForm({ loading }) {
  const { resetPassword, navigateToSignIn } = useAuthState();
  const [email, setEmail] = useState('');
  const [validationError, setValidationError] = useState('');

  const validateEmail = (email) => {
    if (!email) {
      return 'Email is required';
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      return 'Please enter a valid email address';
    }
    return '';
  };

  const handleInputChange = (e) => {
    const value = e.target.value;
    setEmail(value);
    
    // Clear validation error when user starts typing
    if (validationError) {
      setValidationError('');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const error = validateEmail(email);
    if (error) {
      setValidationError(error);
      return;
    }
    
    await resetPassword(email);
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Email Field */}
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">
            Email Address
          </label>
          <div className="relative">
            <input
              type="email"
              id="email"
              value={email}
              onChange={handleInputChange}
              className={`auth-input pl-10 ${validationError ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
              placeholder="Enter your email address"
              disabled={loading}
              autoComplete="email"
              autoFocus
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Icon name="Mail" size={16} className="text-text-muted" />
            </div>
          </div>
          {validationError && (
            <p className="mt-1 text-sm text-error-500 flex items-center gap-1">
              <Icon name="AlertCircle" size={14} />
              {validationError}
            </p>
          )}
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading || !email}
          className="auth-button flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <Icon name="Loader2" size={16} className="animate-spin" />
              Sending Instructions...
            </>
          ) : (
            <>
              <Icon name="Send" size={16} />
              Send Reset Instructions
            </>
          )}
        </button>
      </form>

      {/* Additional Information */}
      <div className="bg-secondary-100 rounded-md p-4">
        <div className="flex items-start gap-3">
          <Icon name="Info" size={16} className="text-primary mt-0.5" />
          <div className="text-sm">
            <p className="text-text-primary font-medium mb-1">What happens next?</p>
            <ul className="text-text-secondary space-y-1">
              <li>• We'll send reset instructions to your email</li>
              <li>• Check your spam folder if you don't see it</li>
              <li>• The reset link expires in 24 hours</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Back to Sign In */}
      <div className="text-center pt-4 border-t border-border">
        <p className="text-sm text-text-secondary">
          Remember your password?{' '}
          <button
            type="button"
            onClick={navigateToSignIn}
            className="auth-link"
            disabled={loading}
          >
            Back to Sign In
          </button>
        </p>
      </div>

      {/* Mock Credentials Info */}
      <div className="mt-6 p-4 bg-secondary-100 rounded-md">
        <p className="text-xs text-text-secondary mb-2 font-medium">Demo Email:</p>
        <p className="text-xs text-text-muted">demo@byto.com</p>
      </div>
    </div>
  );
}

export default PasswordResetForm;