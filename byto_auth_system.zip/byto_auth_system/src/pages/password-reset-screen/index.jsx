import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthState } from 'components/ui/AuthStateRouter';
import AuthFormContainer from 'components/ui/AuthFormContainer';
import Icon from 'components/AppIcon';

function PasswordResetScreen() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [canResend, setCanResend] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [emailError, setEmailError] = useState('');
  
  const navigate = useNavigate();
  const location = useLocation();
  const { resetPassword, loading, error, clearError } = useAuthState();

  // Check if there's a success message from navigation state
  const successMessage = location.state?.message;

  React.useEffect(() => {
    if (successMessage) {
      setIsSubmitted(true);
    }
  }, [successMessage]);

  React.useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => {
        setResendTimer(resendTimer - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (resendTimer === 0 && isSubmitted) {
      setCanResend(true);
    }
  }, [resendTimer, isSubmitted]);

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleEmailChange = (e) => {
    const value = e.target.value;
    setEmail(value);
    
    if (emailError) {
      setEmailError('');
    }
    if (error) {
      clearError();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email.trim()) {
      setEmailError('Email address is required');
      return;
    }
    
    if (!validateEmail(email)) {
      setEmailError('Please enter a valid email address');
      return;
    }

    setEmailError('');
    
    try {
      await resetPassword(email);
      setIsSubmitted(true);
      setCanResend(false);
      setResendTimer(60); // 60 seconds cooldown
    } catch (err) {
      // Error is handled by AuthStateRouter
    }
  };

  const handleResendEmail = async () => {
    if (!canResend) return;
    
    try {
      await resetPassword(email);
      setCanResend(false);
      setResendTimer(60);
    } catch (err) {
      // Error is handled by AuthStateRouter
    }
  };

  const handleBackToSignIn = () => {
    navigate('/sign-in-screen');
  };

  if (isSubmitted && !error) {
    return (
      <AuthFormContainer>
        <div className="text-center">
          <div className="w-16 h-16 bg-success-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Icon name="Mail" size={32} className="text-success-600" />
          </div>
          
          <h1 className="text-2xl font-semibold text-text-primary mb-3">
            Check Your Email
          </h1>
          
          <p className="text-text-secondary mb-6 leading-relaxed">
            We've sent password reset instructions to{' '}
            <span className="font-medium text-text-primary">{email}</span>
          </p>
          
          <div className="bg-secondary-50 rounded-lg p-4 mb-6">
            <div className="flex items-start gap-3">
              <Icon name="Info" size={20} className="text-secondary-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-secondary-700">
                <p className="mb-2">
                  Click the link in the email to reset your password. If you don't see it, check your spam folder.
                </p>
                <p>
                  The link will expire in 24 hours for security reasons.
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-3">
            <button
              onClick={handleResendEmail}
              disabled={!canResend || loading}
              className={`w-full py-2.5 px-4 rounded-md font-medium transition-all duration-200 ${
                canResend && !loading
                  ? 'bg-secondary-100 text-secondary-700 hover:bg-secondary-200 focus:outline-none focus:ring-2 focus:ring-secondary-500/20' :'bg-secondary-50 text-secondary-400 cursor-not-allowed'
              }`}
            >
              {loading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-4 h-4 border-2 border-secondary-400 border-t-transparent rounded-full animate-spin"></div>
                  Sending...
                </div>
              ) : canResend ? (
                'Resend Email'
              ) : (
                `Resend in ${resendTimer}s`
              )}
            </button>
            
            <button
              onClick={handleBackToSignIn}
              className="w-full py-2.5 px-4 text-secondary-600 hover:text-secondary-700 font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-secondary-500/20 rounded-md"
            >
              Back to Sign In
            </button>
          </div>
        </div>
      </AuthFormContainer>
    );
  }

  return (
    <AuthFormContainer>
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Icon name="KeyRound" size={32} className="text-primary-600" />
        </div>
        
        <h1 className="text-2xl font-semibold text-text-primary mb-3">
          Reset Your Password
        </h1>
        
        <p className="text-text-secondary leading-relaxed">
          Enter your email address and we'll send you instructions to reset your password.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">
            Email Address
          </label>
          <div className="relative">
            <input
              id="email"
              type="email"
              value={email}
              onChange={handleEmailChange}
              placeholder="Enter your email address"
              className={`auth-input pl-10 ${
                emailError || error ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''
              }`}
              disabled={loading}
            />
            <Icon 
              name="Mail" 
              size={20} 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted" 
            />
          </div>
          {emailError && (
            <p className="mt-2 text-sm text-error-600 flex items-center gap-1">
              <Icon name="AlertCircle" size={16} />
              {emailError}
            </p>
          )}
        </div>

        {error && (
          <div className="bg-error-50 border border-error-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Icon name="AlertTriangle" size={20} className="text-error-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-error-800 mb-1">Reset Failed</p>
                <p className="text-sm text-error-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={loading || !email.trim()}
          className="auth-button flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Sending Reset Link...
            </>
          ) : (
            <>
              <Icon name="Send" size={20} />
              Send Reset Link
            </>
          )}
        </button>
      </form>

      <div className="mt-8 pt-6 border-t border-border">
        <div className="text-center space-y-4">
          <p className="text-sm text-text-secondary">
            Remember your password?
          </p>
          
          <button
            onClick={handleBackToSignIn}
            className="auth-link inline-flex items-center gap-2 text-sm"
          >
            <Icon name="ArrowLeft" size={16} />
            Back to Sign In
          </button>
        </div>
      </div>
    </AuthFormContainer>
  );
}

export default PasswordResetScreen;