import React, { useState } from 'react';
import { useAuthState } from 'components/ui/AuthStateRouter';
import Icon from 'components/AppIcon';

function SignUpForm({ loading }) {
  const { signUp, navigateToSignIn } = useAuthState();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const validateForm = () => {
    const errors = {};
    
    if (!formData.name.trim()) {
      errors.name = 'Full name is required';
    } else if (formData.name.trim().length < 2) {
      errors.name = 'Name must be at least 2 characters';
    }
    
    if (!formData.email) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }
    
    if (!formData.password) {
      errors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(formData.password)) {
      errors.password = 'Password must contain uppercase, lowercase, and number';
    }
    
    if (!formData.confirmPassword) {
      errors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    
    if (!agreedToTerms) {
      errors.terms = 'You must agree to the terms and conditions';
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear validation error when user starts typing
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    await signUp(formData);
  };

  const togglePasswordVisibility = (field) => {
    if (field === 'password') {
      setShowPassword(!showPassword);
    } else {
      setShowConfirmPassword(!showConfirmPassword);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Name Field */}
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-text-primary mb-2">
          Full Name
        </label>
        <div className="relative">
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            className={`auth-input pl-10 ${validationErrors.name ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
            placeholder="Enter your full name"
            disabled={loading}
            autoComplete="name"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="User" size={16} className="text-text-muted" />
          </div>
        </div>
        {validationErrors.name && (
          <p className="mt-1 text-sm text-error-500 flex items-center gap-1">
            <Icon name="AlertCircle" size={14} />
            {validationErrors.name}
          </p>
        )}
      </div>

      {/* Email Field */}
      <div>
        <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">
          Email Address
        </label>
        <div className="relative">
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            className={`auth-input pl-10 ${validationErrors.email ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
            placeholder="Enter your email"
            disabled={loading}
            autoComplete="email"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="Mail" size={16} className="text-text-muted" />
          </div>
        </div>
        {validationErrors.email && (
          <p className="mt-1 text-sm text-error-500 flex items-center gap-1">
            <Icon name="AlertCircle" size={14} />
            {validationErrors.email}
          </p>
        )}
      </div>

      {/* Password Field */}
      <div>
        <label htmlFor="password" className="block text-sm font-medium text-text-primary mb-2">
          Password
        </label>
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            id="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            className={`auth-input pl-10 pr-10 ${validationErrors.password ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
            placeholder="Create a password"
            disabled={loading}
            autoComplete="new-password"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="Lock" size={16} className="text-text-muted" />
          </div>
          <button
            type="button"
            onClick={() => togglePasswordVisibility('password')}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-text-muted hover:text-text-primary transition-colors duration-200"
            disabled={loading}
          >
            <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={16} />
          </button>
        </div>
        {validationErrors.password && (
          <p className="mt-1 text-sm text-error-500 flex items-center gap-1">
            <Icon name="AlertCircle" size={14} />
            {validationErrors.password}
          </p>
        )}
      </div>

      {/* Confirm Password Field */}
      <div>
        <label htmlFor="confirmPassword" className="block text-sm font-medium text-text-primary mb-2">
          Confirm Password
        </label>
        <div className="relative">
          <input
            type={showConfirmPassword ? 'text' : 'password'}
            id="confirmPassword"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleInputChange}
            className={`auth-input pl-10 pr-10 ${validationErrors.confirmPassword ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
            placeholder="Confirm your password"
            disabled={loading}
            autoComplete="new-password"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="Lock" size={16} className="text-text-muted" />
          </div>
          <button
            type="button"
            onClick={() => togglePasswordVisibility('confirmPassword')}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-text-muted hover:text-text-primary transition-colors duration-200"
            disabled={loading}
          >
            <Icon name={showConfirmPassword ? 'EyeOff' : 'Eye'} size={16} />
          </button>
        </div>
        {validationErrors.confirmPassword && (
          <p className="mt-1 text-sm text-error-500 flex items-center gap-1">
            <Icon name="AlertCircle" size={14} />
            {validationErrors.confirmPassword}
          </p>
        )}
      </div>

      {/* Terms and Conditions */}
      <div className="flex items-start gap-3">
        <input
          type="checkbox"
          id="terms"
          checked={agreedToTerms}
          onChange={(e) => {
            setAgreedToTerms(e.target.checked);
            if (validationErrors.terms) {
              setValidationErrors(prev => ({
                ...prev,
                terms: ''
              }));
            }
          }}
          className="mt-1 h-4 w-4 text-primary focus:ring-primary border-border rounded"
          disabled={loading}
        />
        <label htmlFor="terms" className="text-sm text-text-secondary">
          I agree to the{' '}
          <a href="#" className="auth-link">Terms of Service</a>
          {' '}and{' '}
          <a href="#" className="auth-link">Privacy Policy</a>
        </label>
      </div>
      {validationErrors.terms && (
        <p className="text-sm text-error-500 flex items-center gap-1">
          <Icon name="AlertCircle" size={14} />
          {validationErrors.terms}
        </p>
      )}

      {/* Submit Button */}
      <button
        type="submit"
        disabled={loading}
        className="auth-button flex items-center justify-center gap-2"
      >
        {loading ? (
          <>
            <Icon name="Loader2" size={16} className="animate-spin" />
            Creating Account...
          </>
        ) : (
          <>
            <Icon name="UserPlus" size={16} />
            Create Account
          </>
        )}
      </button>

      {/* Sign In Link */}
      <div className="text-center pt-4 border-t border-border">
        <p className="text-sm text-text-secondary">
          Already have an account?{' '}
          <button
            type="button"
            onClick={navigateToSignIn}
            className="auth-link"
            disabled={loading}
          >
            Sign In
          </button>
        </p>
      </div>
    </form>
  );
}

export default SignUpForm;