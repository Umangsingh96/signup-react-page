import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import AuthFormContainer from 'components/ui/AuthFormContainer';
import { useAuthState } from 'components/ui/AuthStateRouter';
import Icon from 'components/AppIcon';

function SignUpScreen() {
  const location = useLocation();
  const { signUp, loading, error, clearError, navigateToSignIn } = useAuthState();
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    company: '',
    agreeToTerms: false,
    agreeToPrivacy: false
  });

  const [validation, setValidation] = useState({
    fullName: { isValid: true, message: '' },
    email: { isValid: true, message: '' },
    password: { isValid: true, message: '' },
    confirmPassword: { isValid: true, message: '' },
    terms: { isValid: true, message: '' }
  });

  const [showOptionalFields, setShowOptionalFields] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState({
    score: 0,
    feedback: []
  });

  // Clear error when component mounts or location changes
  useEffect(() => {
    clearError();
  }, [location, clearError]);

  // Password strength calculation
  useEffect(() => {
    const calculatePasswordStrength = (password) => {
      let score = 0;
      const feedback = [];

      if (password.length >= 8) {
        score += 1;
      } else {
        feedback.push('At least 8 characters');
      }

      if (/[A-Z]/.test(password)) {
        score += 1;
      } else {
        feedback.push('One uppercase letter');
      }

      if (/[a-z]/.test(password)) {
        score += 1;
      } else {
        feedback.push('One lowercase letter');
      }

      if (/\d/.test(password)) {
        score += 1;
      } else {
        feedback.push('One number');
      }

      if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        score += 1;
      } else {
        feedback.push('One special character');
      }

      return { score, feedback };
    };

    if (formData.password) {
      setPasswordStrength(calculatePasswordStrength(formData.password));
    } else {
      setPasswordStrength({ score: 0, feedback: [] });
    }
  }, [formData.password]);

  const validateField = (name, value) => {
    switch (name) {
      case 'fullName':
        if (!value.trim()) {
          return { isValid: false, message: 'Full name is required' };
        }
        if (value.trim().length < 2) {
          return { isValid: false, message: 'Full name must be at least 2 characters' };
        }
        return { isValid: true, message: '' };

      case 'email':
        if (!value.trim()) {
          return { isValid: false, message: 'Email is required' };
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
          return { isValid: false, message: 'Please enter a valid email address' };
        }
        return { isValid: true, message: '' };

      case 'password':
        if (!value) {
          return { isValid: false, message: 'Password is required' };
        }
        if (value.length < 8) {
          return { isValid: false, message: 'Password must be at least 8 characters' };
        }
        return { isValid: true, message: '' };

      case 'confirmPassword':
        if (!value) {
          return { isValid: false, message: 'Please confirm your password' };
        }
        if (value !== formData.password) {
          return { isValid: false, message: 'Passwords do not match' };
        }
        return { isValid: true, message: '' };

      case 'terms':
        if (!formData.agreeToTerms || !formData.agreeToPrivacy) {
          return { isValid: false, message: 'Please accept the terms and privacy policy' };
        }
        return { isValid: true, message: '' };

      default:
        return { isValid: true, message: '' };
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;

    setFormData(prev => ({
      ...prev,
      [name]: newValue
    }));

    // Validate field on change
    if (name !== 'phone' && name !== 'company') {
      const fieldValidation = validateField(name, newValue);
      setValidation(prev => ({
        ...prev,
        [name]: fieldValidation
      }));
    }

    // Special handling for terms validation
    if (name === 'agreeToTerms' || name === 'agreeToPrivacy') {
      const termsValidation = validateField('terms', newValue);
      setValidation(prev => ({
        ...prev,
        terms: termsValidation
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate all required fields
    const validations = {
      fullName: validateField('fullName', formData.fullName),
      email: validateField('email', formData.email),
      password: validateField('password', formData.password),
      confirmPassword: validateField('confirmPassword', formData.confirmPassword),
      terms: validateField('terms', '')
    };

    setValidation(validations);

    // Check if all validations pass
    const isFormValid = Object.values(validations).every(v => v.isValid);

    if (isFormValid) {
      await signUp(formData);
    }
  };

  const getPasswordStrengthColor = () => {
    if (passwordStrength.score <= 1) return 'bg-error-500';
    if (passwordStrength.score <= 3) return 'bg-warning-500';
    return 'bg-success-500';
  };

  const getPasswordStrengthText = () => {
    if (passwordStrength.score <= 1) return 'Weak';
    if (passwordStrength.score <= 3) return 'Medium';
    return 'Strong';
  };

  return (
    <div className="min-h-screen bg-background">
      <AuthFormContainer>
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-text-primary mb-2">Create Account</h1>
          <p className="text-text-secondary">Join us today and get started</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-error-100 border border-error-500 rounded-md">
            <div className="flex items-center gap-2">
              <Icon name="AlertCircle" size={20} className="text-error-500" />
              <p className="text-error-600 text-sm">{error}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Full Name */}
          <div>
            <label htmlFor="fullName" className="block text-sm font-medium text-text-primary mb-2">
              Full Name *
            </label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleInputChange}
              className={`auth-input ${!validation.fullName.isValid ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
              placeholder="Enter your full name"
              disabled={loading}
            />
            {!validation.fullName.isValid && (
              <p className="mt-1 text-sm text-error-600">{validation.fullName.message}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">
              Email Address *
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className={`auth-input ${!validation.email.isValid ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
              placeholder="Enter your email"
              disabled={loading}
            />
            {!validation.email.isValid && (
              <p className="mt-1 text-sm text-error-600">{validation.email.message}</p>
            )}
          </div>

          {/* Password */}
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-text-primary mb-2">
              Password *
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              className={`auth-input ${!validation.password.isValid ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
              placeholder="Create a password"
              disabled={loading}
            />
            {!validation.password.isValid && (
              <p className="mt-1 text-sm text-error-600">{validation.password.message}</p>
            )}
            
            {/* Password Strength Indicator */}
            {formData.password && (
              <div className="mt-2">
                <div className="flex items-center gap-2 mb-1">
                  <div className="flex-1 bg-secondary-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${getPasswordStrengthColor()}`}
                      style={{ width: `${(passwordStrength.score / 5) * 100}%` }}
                    />
                  </div>
                  <span className={`text-xs font-medium ${passwordStrength.score <= 1 ? 'text-error-600' : passwordStrength.score <= 3 ? 'text-warning-600' : 'text-success-600'}`}>
                    {getPasswordStrengthText()}
                  </span>
                </div>
                {passwordStrength.feedback.length > 0 && (
                  <p className="text-xs text-text-muted">
                    Missing: {passwordStrength.feedback.join(', ')}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Confirm Password */}
          <div>
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-text-primary mb-2">
              Confirm Password *
            </label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleInputChange}
              className={`auth-input ${!validation.confirmPassword.isValid ? 'border-error-500 focus:border-error-500 focus:ring-error-500/20' : ''}`}
              placeholder="Confirm your password"
              disabled={loading}
            />
            {!validation.confirmPassword.isValid && (
              <p className="mt-1 text-sm text-error-600">{validation.confirmPassword.message}</p>
            )}
          </div>

          {/* Optional Fields Toggle */}
          <div>
            <button
              type="button"
              onClick={() => setShowOptionalFields(!showOptionalFields)}
              className="flex items-center gap-2 text-primary hover:text-primary-700 text-sm font-medium transition-colors duration-200"
            >
              <Icon name={showOptionalFields ? "ChevronUp" : "ChevronDown"} size={16} />
              {showOptionalFields ? 'Hide' : 'Show'} optional fields
            </button>
          </div>

          {/* Optional Fields */}
          {showOptionalFields && (
            <div className="space-y-4 pt-2 border-t border-border">
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-text-primary mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className="auth-input"
                  placeholder="Enter your phone number"
                  disabled={loading}
                />
              </div>

              <div>
                <label htmlFor="company" className="block text-sm font-medium text-text-primary mb-2">
                  Company
                </label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleInputChange}
                  className="auth-input"
                  placeholder="Enter your company name"
                  disabled={loading}
                />
              </div>
            </div>
          )}

          {/* Terms and Privacy */}
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="agreeToTerms"
                name="agreeToTerms"
                checked={formData.agreeToTerms}
                onChange={handleInputChange}
                className="mt-1 h-4 w-4 text-primary focus:ring-primary border-border rounded"
                disabled={loading}
              />
              <label htmlFor="agreeToTerms" className="text-sm text-text-secondary">
                I agree to the{' '}
                <button type="button" className="auth-link">
                  Terms of Service
                </button>
              </label>
            </div>

            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="agreeToPrivacy"
                name="agreeToPrivacy"
                checked={formData.agreeToPrivacy}
                onChange={handleInputChange}
                className="mt-1 h-4 w-4 text-primary focus:ring-primary border-border rounded"
                disabled={loading}
              />
              <label htmlFor="agreeToPrivacy" className="text-sm text-text-secondary">
                I agree to the{' '}
                <button type="button" className="auth-link">
                  Privacy Policy
                </button>
              </label>
            </div>

            {!validation.terms.isValid && (
              <p className="text-sm text-error-600">{validation.terms.message}</p>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="auth-button flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Icon name="Loader2" size={20} className="animate-spin" />
                Creating Account...
              </>
            ) : (
              <>
                <Icon name="UserPlus" size={20} />
                Create Account
              </>
            )}
          </button>

          {/* Social Registration */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-surface text-text-muted">Or sign up with</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              className="flex items-center justify-center gap-2 px-4 py-2 border border-border rounded-md bg-surface hover:bg-secondary-50 text-text-primary font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary/20"
              disabled={loading}
            >
              <Icon name="Mail" size={18} />
              Google
            </button>
            <button
              type="button"
              className="flex items-center justify-center gap-2 px-4 py-2 border border-border rounded-md bg-surface hover:bg-secondary-50 text-text-primary font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary/20"
              disabled={loading}
            >
              <Icon name="Github" size={18} />
              GitHub
            </button>
          </div>

          {/* Sign In Link */}
          <div className="text-center">
            <p className="text-text-secondary text-sm">
              Already have an account?{' '}
              <button
                type="button"
                onClick={navigateToSignIn}
                className="auth-link"
                disabled={loading}
              >
                Sign in here
              </button>
            </p>
          </div>
        </form>
      </AuthFormContainer>
    </div>
  );
}

export default SignUpScreen;