import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const AuthStateContext = createContext();

export const useAuthState = () => {
  const context = useContext(AuthStateContext);
  if (!context) {
    throw new Error('useAuthState must be used within an AuthStateProvider');
  }
  return context;
};

function AuthStateRouter({ children }) {
  const [authState, setAuthState] = useState({
    isAuthenticated: false,
    user: null,
    loading: false,
    error: null
  });
  
  const navigate = useNavigate();
  const location = useLocation();

  const updateAuthState = (newState) => {
    setAuthState(prev => ({ ...prev, ...newState }));
  };

  const signIn = async (credentials) => {
    updateAuthState({ loading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user = { 
        email: credentials.email, 
        name: credentials.email.split('@')[0] 
      };
      
      updateAuthState({ 
        isAuthenticated: true, 
        user, 
        loading: false 
      });
      
      navigate('/authentication-success-screen');
    } catch (error) {
      updateAuthState({ 
        loading: false, 
        error: 'Invalid credentials. Please try again.' 
      });
    }
  };

  const signUp = async (userData) => {
    updateAuthState({ loading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user = { 
        email: userData.email, 
        name: userData.name || userData.email.split('@')[0] 
      };
      
      updateAuthState({ 
        isAuthenticated: true, 
        user, 
        loading: false 
      });
      
      navigate('/authentication-success-screen');
    } catch (error) {
      updateAuthState({ 
        loading: false, 
        error: 'Registration failed. Please try again.' 
      });
    }
  };

  const resetPassword = async (email) => {
    updateAuthState({ loading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      updateAuthState({ loading: false });
      
      // Navigate back to sign in with success message
      navigate('/sign-in-screen', { 
        state: { message: 'Password reset instructions sent to your email.' }
      });
    } catch (error) {
      updateAuthState({ 
        loading: false, 
        error: 'Failed to send reset instructions. Please try again.' 
      });
    }
  };

  const signOut = () => {
    updateAuthState({ 
      isAuthenticated: false, 
      user: null, 
      loading: false, 
      error: null 
    });
    navigate('/sign-in-screen');
  };

  const clearError = () => {
    updateAuthState({ error: null });
  };

  const navigateToSignIn = () => {
    navigate('/sign-in-screen');
  };

  const navigateToSignUp = () => {
    navigate('/sign-up-screen');
  };

  const navigateToPasswordReset = () => {
    navigate('/password-reset-screen');
  };

  const contextValue = {
    ...authState,
    signIn,
    signUp,
    resetPassword,
    signOut,
    clearError,
    navigateToSignIn,
    navigateToSignUp,
    navigateToPasswordReset,
    updateAuthState
  };

  return (
    <AuthStateContext.Provider value={contextValue}>
      {children}
    </AuthStateContext.Provider>
  );
}

export default AuthStateRouter;