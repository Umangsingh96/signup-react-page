import React from 'react';

function AuthFormContainer({ children, className = "" }) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-auth">
        <div className={`auth-container animate-fade-in ${className}`}>
          {children}
        </div>
      </div>
    </div>
  );
}

export default AuthFormContainer;